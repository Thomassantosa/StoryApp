package com.example.storyappsubmission.data.request

data class LoginRequest(
    var email: String,
    var password: String
)