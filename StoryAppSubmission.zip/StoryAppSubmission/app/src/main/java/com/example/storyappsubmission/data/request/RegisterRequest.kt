package com.example.storyappsubmission.data.request

data class RegisterRequest(
    var name: String,
    var email: String,
    var password: String
)